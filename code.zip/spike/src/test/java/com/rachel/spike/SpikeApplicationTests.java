package com.rachel.spike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpikeApplicationTests {

    @Test
    void contextLoads() {
    }

}
