package com.rachel.spike.template;

public class RedisKey {


    public static final String HASH_KEY = "ACTIVITY_HASH_CODE";
    public static final String ACTIVITY_PREFIX = "activity_";
}
