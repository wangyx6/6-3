package com.rachel.spike.listener;

import com.rachel.spike.service.IOrderService;
import com.rachel.spike.template.RocketMQUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Slf4j
@RocketMQMessageListener(topic = RocketMQUtils.TOPIC_DELAY,consumerGroup = "topic-order-cancel")
public class RocketMQCancelOrderListener implements RocketMQListener<String> {

    @Resource
    private IOrderService orderService;


    @SneakyThrows
    @Override
    public void onMessage(String message) {
        log.info("定时队列消息");
        String[] messages = message.split("_");
        String orderId = messages[1];
        orderService.cancelOrderFromMessage(Long.parseLong(orderId));
    }
}

