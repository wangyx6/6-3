package com.rachel.spike.service.impl;

import com.rachel.spike.dao.ActivityDao;
import com.rachel.spike.dao.OrderDao;
import com.rachel.spike.po.ActivityPO;
import com.rachel.spike.po.OrderPO;
import com.rachel.spike.service.IActivityService;
import com.rachel.spike.service.IOrderService;
import com.rachel.spike.template.RedisKey;
import com.rachel.spike.template.RedisUtils;
import com.rachel.spike.template.RocketMQUtils;
import com.rachel.spike.utils.OrderUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.Optional;

@Service
public class OrderServiceImpl implements IOrderService {

    @Resource
    private IActivityService activityService;

    @Resource
    private ActivityDao activityDao;

    @Resource
    private OrderDao orderDao;

    @Resource
    private RedisUtils redisUtils;

    @Resource
    private RocketMQUtils rocketMQUtils;

    @Override
    public boolean createOrderToMessage(Long userId, Long activityId, String hashCode) throws Exception {
        // 判断当前code使用认证
        String hashKey = RedisKey.HASH_KEY + "_" + userId + "_" + activityId;
        String code = redisUtils.getObject(hashKey, String.class);
        if(null == hashCode || !hashCode.equals(code)){
            throw new RuntimeException("下单失败，请重新下单");
        }
        // 根据获取id，判断是否存在当前活动
        // 由于是高并发场景，此次从redis缓存中取出数据
        ActivityPO activityPO = activityService.getActivityById(activityId);
        if(null == activityPO){
            activityPO = activityService.getActivityById(activityId);
        }
        if(null == activityPO){
            throw new RuntimeException("活动不存在");
        }

        // 判断秒杀是否已经结束
        if(activityPO.getStatus() == ActivityPO.STATUS_START){
            throw new RuntimeException("活动未开始");
        }
        if(activityPO.getStatus() == ActivityPO.STATUS_END){
            throw new RuntimeException("活动已结束");
        }
        // 判断库存是否还有
        if(activityPO.getStock() <= 0){
            throw new RuntimeException("商品已售完，秒杀结束");
        }
        // 更新redis中库存数量
        activityPO.setStock(activityPO.getStock() - 1);
        redisUtils.putObject(RedisKey.ACTIVITY_PREFIX + activityId, activityPO);

        // 发送消息到消息队列
        rocketMQUtils.sendMessage(RocketMQUtils.TOPIC_ORDER, RocketMQUtils.KEY_PREFIX + userId + "_" + activityId, null);
        return true;
    }

    @Override
    public boolean createOrderFromMessage(Long userId, Long activityId) throws Exception {

        // 扣库存，生成订单
        if(activityDao.updateActivityStock(activityId) == 0){
            throw new RuntimeException("秒杀库存不足，不创建订单");
        }

        ActivityPO activityPO = activityService.getActivityById(activityId);
        // 生产订单
        OrderPO orderPo = new OrderPO();
        orderPo.setActivityId(activityPO.getId());
        orderPo.setUserId(userId);
        orderPo.setCreateDate(new Date());
        orderPo.setGoodsId(activityPO.getGoodId());
        orderPo.setPrice(activityPO.getPrice());
        orderPo.setStatus(OrderPO.STATUS_PAY);
        orderPo.setOrderNo(OrderUtils.nextOrderNo());
        orderDao.save(orderPo);
        // 订单生成，发送消息到消息队列，否则30分钟后自动取消订单
        rocketMQUtils.sendMessage(RocketMQUtils.TOPIC_DELAY, RocketMQUtils.KEY_PREFIX + orderPo.getId(), RocketMQUtils.EXPIRE_LEVEL);
        return true;
    }

    @Override
    public boolean cancelOrderFromMessage(Long orderId) {
        OrderPO orderPo = orderDao.getOne(orderId);
        // 判断订单是否已经支付
        if(orderPo.getStatus() == OrderPO.STATUS_PAY){
            orderPo.setStatus(OrderPO.STATUS_FINISH);
            orderDao.save(orderPo);
            // 修改redis中的库存
            ActivityPO activityPO = redisUtils.getObject(RedisKey.ACTIVITY_PREFIX + orderPo.getActivityId(), ActivityPO.class);
            activityPO.setStock(activityPO.getStock() + 1);
            redisUtils.putObject(RedisKey.ACTIVITY_PREFIX + orderPo.getActivityId(), activityPO);
        }
        return true;
    }

    @Override
    public boolean payOrder(Long orderId) {
        //获取订单信息
        final Optional<OrderPO> orderOptional = orderDao.findById(orderId);
        if(orderOptional.isEmpty()){
            throw new RuntimeException("订单不存在");
        }
        OrderPO orderPO = orderOptional.get();
        if(orderPO.getStatus() == OrderPO.STATUS_FINISH){
            throw new RuntimeException("订单超时已取消");
        }
        orderPO.setStatus(OrderPO.STATUS_PAY_FINISH);
        orderDao.save(orderPO);
        return true;
    }
}
