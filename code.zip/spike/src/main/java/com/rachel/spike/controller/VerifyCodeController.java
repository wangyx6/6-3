package com.rachel.spike.controller;

import cn.hutool.core.util.RandomUtil;
import com.rachel.spike.service.IActivityService;
import com.rachel.spike.service.impl.ActivityServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/verify/code")
public class VerifyCodeController {

    @Resource
    private IActivityService activityService;

    @GetMapping("/hash/{userId}/{activityId}")
    ResponseEntity getVerifyHash(@PathVariable Long userId, @PathVariable Long activityId){
        return ResponseEntity.ok(activityService.getVerifyHash(userId,activityId));
    }


}
