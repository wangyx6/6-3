package com.rachel.spike.po;

import lombok.Data;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "da_order")
@Proxy(lazy = false)
public class OrderPO {

    // 订单完成
    public static Integer STATUS_FINISH = 2;
    // 待付款
    public static Integer STATUS_PAY = 0;
    // 已付款
    public static Integer STATUS_PAY_FINISH = 1;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 商品id
     */
    private Long goodsId;

    /**
     * 活动id
     */
    private Long activityId;

    /**
     * 订单号
     */
    private String orderNo;

    /**
     * 订单金额
     */
    private double price;

    /**
     * 订单创建时间
     */
    private Date createDate;

    /**
     * 付款时间
     */
    private Date payDate;

    /**
     * 订单创建人
     */
    private Long userId;

    /**
     * 订单状态
     */
    private Integer status;


}
