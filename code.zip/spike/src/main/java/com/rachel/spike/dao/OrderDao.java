package com.rachel.spike.dao;

import com.rachel.spike.po.OrderPO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderDao extends JpaRepository<OrderPO, Long> {
}
