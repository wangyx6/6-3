package com.rachel.spike.vo;

import lombok.Data;

import java.util.Date;

@Data
public class SpikeAcitvityVO {

    private Long id;

    /**
     * 商品id
     */
    private Long goodId;

    /**
     * 秒杀商品价格
     */
    private double price;

    /**
     * 秒杀创建时间
     */
    private Date createDate;

    /**
     * 秒杀开始时间
     */
    private Date startDate;

    /**
     * 秒杀数量
     */
    private Integer stock;

    /**
     * 秒杀状态
     */
    private Integer status;
}
