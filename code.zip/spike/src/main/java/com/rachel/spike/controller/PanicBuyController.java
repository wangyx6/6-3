package com.rachel.spike.controller;

import com.rachel.spike.dao.ActivityDao;
import com.rachel.spike.dao.GoodsDao;
import com.rachel.spike.po.ActivityPO;
import com.rachel.spike.po.GoodsPO;
import com.rachel.spike.service.IActivityService;
import com.rachel.spike.service.IOrderService;
import com.rachel.spike.template.RedisKey;
import com.rachel.spike.template.RedisUtils;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * 抢购相关的controller
 * @author wangyx
 * @see PanicBuyController
 * @since 2020/11/26
 */
@RestController
@RequestMapping("/panic")
public class PanicBuyController {


    @Autowired
    private GoodsDao goodsDao;

    @Autowired
    private IOrderService orderService;

    @Autowired
    private ActivityDao activityDao;

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    @Resource
    private RedisUtils redisUtils;

    @Resource
    private IActivityService activityService;

    /**
     * 获取秒杀商品列表
     * @return
     */
    @GetMapping("/spike/activity")
    ResponseEntity<List<ActivityPO>> getSpikeActivityList(){
        return ResponseEntity.ok(activityService.getActivityList());
    }

    @PutMapping("/pay/{userId}/{activityId}/{code}")
    ResponseEntity<Boolean> paySpikeGoods(@PathVariable Long userId, @PathVariable Long activityId, @PathVariable String code) throws Exception {
        return ResponseEntity.ok(orderService.createOrderToMessage(userId, activityId, code));
    }

    /**
     * 创建秒杀活动
     * @param goodsId 商品id
     * @param num 秒杀数量
     * @return
     */
    @PutMapping("/{goodsId}/{num}/{price}/{startDate}")
    public ResponseEntity<Boolean> createSpikeActivity(@PathVariable Long goodsId,@PathVariable Double price, @PathVariable Integer num,@PathVariable String startDate) throws ParseException {
        // 获取商品是否存在 以及 是否库存还够秒杀的商品数量
        Optional<GoodsPO> goodsOptional = goodsDao.findById(goodsId);
        if(goodsOptional.isEmpty() || goodsOptional.get().getStock() < num){
            return ResponseEntity.ok(false);
        }
        // 创建秒杀活动
        ActivityPO activityPO = new ActivityPO();
        activityPO.setGoodId(goodsId);
        activityPO.setCreateDate(new Date());
        activityPO.setPrice(price);
        activityPO.setStartDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startDate));
        activityPO.setStock(num);
        activityPO.setStatus(ActivityPO.STATUS_NO_START);
        activityDao.save(activityPO);
        // 将数据查询出来，写入redis缓冲，防止秒杀时，直接查询db
        redisUtils.putObject(RedisKey.ACTIVITY_PREFIX + activityPO.getId(), activityPO);
        return ResponseEntity.ok(true);
    }

    @PutMapping("/pay/{orderId}")
    public ResponseEntity pay(@PathVariable Long orderId){
        return ResponseEntity.ok(orderService.payOrder(orderId));
    }

}
