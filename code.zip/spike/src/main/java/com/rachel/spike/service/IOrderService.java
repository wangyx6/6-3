package com.rachel.spike.service;

public interface IOrderService {

    boolean createOrderToMessage(Long userId, Long activityId, String hashCode) throws Exception;

    boolean createOrderFromMessage(Long userId, Long activityId) throws Exception;

    boolean cancelOrderFromMessage(Long orderId);

    boolean payOrder(Long orderId);
}
