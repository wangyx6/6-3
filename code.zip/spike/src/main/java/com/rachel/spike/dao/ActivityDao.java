package com.rachel.spike.dao;

import com.rachel.spike.po.ActivityPO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ActivityDao extends JpaRepository<ActivityPO, Long> {

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update ActivityPO p set p.stock = (p.stock -1) where p.id = ?1 and p.stock > 0 ")
    Integer updateActivityStock(Long id);
}
