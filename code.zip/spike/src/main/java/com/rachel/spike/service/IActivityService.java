package com.rachel.spike.service;


import com.rachel.spike.po.ActivityPO;

import java.util.List;

public interface IActivityService {

    /**
     * 根据商品，
     * @param userId
     * @param activityId
     * @return
     */
    String getVerifyHash(Long userId, Long activityId );

    boolean activityStart(Long activityId);

    List<ActivityPO> getActivityList();

    ActivityPO getActivityById(Long activityId);
}
