package com.rachel.spike.vo;

import lombok.Data;

@Data
public class SpikeGoodsVO {

    private Long id;
    /**
     * 商品名称
     */
    private String name;

    /**
     * 库存数量
     */
    private Integer stock;

    /**
     * 商品价格
     */
    private double price;
}
