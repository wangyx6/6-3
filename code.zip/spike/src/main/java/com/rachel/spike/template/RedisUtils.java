package com.rachel.spike.template;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Component
public class RedisUtils {

    @Resource
    private RedisTemplate redisTemplate;

    public boolean putObject(String id, Object object){
        redisTemplate.opsForValue().set(id, JSONObject.toJSONString(object));
        return true;
    }

    public <T>T getObject(String redisKey, Class<T> clazz) {
        String ret = (String) redisTemplate.opsForValue().get(redisKey);
        if(StringUtils.isNotBlank(ret)){
            if(clazz == String.class){
                return (T) ret;
            }
            return JSONObject.parseObject(ret, clazz);
        }
        return null;
    }

    public <T> List<T> getList(String keyPrefix, Class<T> clazz) {
        Set keys = redisTemplate.keys(keyPrefix);
        if(keys.isEmpty()){
            return null;
        }
        return multiGet(keys, clazz);
    }

    public <T> List<T> multiGet(Set<String> keys, Class<T> clazz) {
        List list = redisTemplate.opsForValue().multiGet(keys);
        List<T> retList = new ArrayList<>();
        for (Object stringValue : list) {
            retList.add(JSONObject.parseObject((String) stringValue, clazz));
        }
        return retList;
    }

    public boolean putString(String hashKey, String verifyCode) {
        redisTemplate.opsForValue().set(hashKey, verifyCode);
        return true;
    }
}
