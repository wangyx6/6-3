package com.rachel.spike.po;

import lombok.Data;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;

@Entity
@Table(name = "da_user")
@Data
@Proxy(lazy = false)
public class UserPO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String displayName;

    private String loginName;

    private String phone;
}
