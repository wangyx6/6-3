package com.rachel.spike.service.impl;

import cn.hutool.core.util.RandomUtil;
import com.rachel.spike.dao.ActivityDao;
import com.rachel.spike.dao.UserDao;
import com.rachel.spike.po.ActivityPO;
import com.rachel.spike.po.UserPO;
import com.rachel.spike.service.IActivityService;
import com.rachel.spike.template.RedisKey;
import com.rachel.spike.template.RedisUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ActivityServiceImpl implements IActivityService {

    @Resource
    private UserDao userDao;

    @Resource
    private ActivityDao activityDao;

    @Resource
    private RedisUtils redisUtils;

    @Override
    public String getVerifyHash(Long userId, Long activityId) {

        // 判断用户是否存在
        Optional<UserPO> userOptional = userDao.findById(userId);
        if(userOptional.isEmpty()){
            throw new RuntimeException("用户存在在");
        }
        // 判断活动是否存在
        if(!activityStart(activityId)){
            throw new RuntimeException("活动不存在或未开始");
        }
        // 根据活动id以及用户id生产hash编码
        String hashKey = RedisKey.HASH_KEY + "_" + userId + "_" + activityId;
        String verifyCode = RandomUtil.randomString(8);
        redisUtils.putString(hashKey, verifyCode);
        return verifyCode;
    }

    @Override
    public boolean activityStart(Long activityId) {

        ActivityPO activityPo = getActivityById(activityId);
        if(null == activityPo){
            throw new RuntimeException("秒杀活动不存在");
        }
        if(activityPo.getStartDate().before(new Date())){
            return true;
        }
        return false;
    }

    @Override
    public List<ActivityPO> getActivityList() {
        return activityDao.findAll();
    }

    @Override
    public ActivityPO getActivityById(Long activityId) {
        // 从redis中获取活动详情
        ActivityPO activityPo = redisUtils.getObject(RedisKey.ACTIVITY_PREFIX + activityId, ActivityPO.class);
        if(null == activityPo){
            Optional<ActivityPO> activityOptional = activityDao.findById(activityId);
            if(!activityOptional.isEmpty()){
                redisUtils.putObject(RedisKey.ACTIVITY_PREFIX + activityId, activityOptional.get());
                activityPo = activityOptional.get();
            }
        }
        return activityPo;
    }
}
