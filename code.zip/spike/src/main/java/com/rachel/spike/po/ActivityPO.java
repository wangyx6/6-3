package com.rachel.spike.po;

import lombok.Data;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "da_activity")
@Proxy(lazy = false)
public class ActivityPO {

    public static Integer STATUS_NO_START = 0;
    public static Integer STATUS_START = 1;
    public static Integer STATUS_END = 2;


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * 商品id
     */
    private Long goodId;

    /**
     * 秒杀商品价格
     */
    private double price;

    /**
     * 秒杀创建时间
     */
    private Date createDate;

    /**
     * 秒杀开始时间
     */
    private Date startDate;

    /**
     * 秒杀数量
     */
    private Integer stock;

    /**
     * 秒杀状态
     */
    private Integer status;
}
