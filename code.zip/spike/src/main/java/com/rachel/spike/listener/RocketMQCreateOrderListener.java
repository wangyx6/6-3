package com.rachel.spike.listener;

import com.rachel.spike.service.IOrderService;
import com.rachel.spike.template.RocketMQUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Slf4j
@RocketMQMessageListener(topic = RocketMQUtils.TOPIC_ORDER,consumerGroup = "topic-order-delay")
public class RocketMQCreateOrderListener implements RocketMQListener<String> {

    @Resource
    private IOrderService orderService;

    @SneakyThrows
    @Override
    public void onMessage(String message) {
        log.info("创建消息队列获取消息");

        String[] messages = message.split("_");
        orderService.createOrderFromMessage(Long.parseLong(messages[1]), Long.parseLong(messages[2]));
    }
}
