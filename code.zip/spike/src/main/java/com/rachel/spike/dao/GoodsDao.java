package com.rachel.spike.dao;

import com.rachel.spike.po.GoodsPO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GoodsDao extends JpaRepository<GoodsPO, Long> {
}
