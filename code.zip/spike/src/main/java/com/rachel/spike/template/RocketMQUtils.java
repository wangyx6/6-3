package com.rachel.spike.template;

import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class RocketMQUtils {

    public static final String KEY_PREFIX = "topic_";
    public static final String TOPIC_DELAY = "topic_delay";
    public static final String TOPIC_ORDER = "topic_order";
    public static final Integer EXPIRE_LEVEL = 3;

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    public boolean sendMessage(String topic, String messageObject, Integer expireTime) throws Exception{
        if(null != expireTime) {
            rocketMQTemplate.syncSend(topic, MessageBuilder.withPayload(messageObject).build(), 5000, expireTime);
        } else{
            rocketMQTemplate.syncSend(topic, MessageBuilder.withPayload(messageObject).build());
        }
        return true;
    }
}
